﻿//author: Thando Masina
//Date: 19 June 2024
//Purpose: Typing tutor game for project

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TypingTutorGame
{
    public partial class Form1 : Form
    {
        string[] words = { "Programming", "Microsoft", "Engineering", "Volkswagen", "Process", "I am a developer!", "Exceptions" };

        Random random = new Random();

        int correct = 0;
        int incorrect = 0;

        public Form1()
        {
            InitializeComponent();

            lblWord.Text = words[random.Next(0, words.Length)];
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void checkGame(object sender, KeyEventArgs e)
        {
                if (e.KeyCode == Keys.Enter)
                {

                    if (textBox1.Text == lblWord.Text)
                    {
                        correct++;
                        lblWord.Text = words[random.Next(0, words.Length)];
                        textBox1.Text = null; 
                        Application.Exit(); //this will allow app to quit if correct answer has been typed.
                    }
                    else
                    {
                        incorrect++;
                        lblWord.Text = words[random.Next(0, words.Length)];
                        textBox1.Text = null;
                    }

                    lblright.Text = "Correct: " + correct;
                    lblwrong.Text = "Incorrect: " + incorrect;
                }
        }

        private void btnQuit_Click(object sender, EventArgs e)
        {
            //Creates the Messagebox with certain specification.
            DialogResult result = MessageBox.Show("Would you like to continue with this program?", "Continue", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);

            //If yes is selected.
            if (result == DialogResult.Yes)
            {
                MessageBox.Show("Yes");
            }
            //If no is selected.
            else if (result == DialogResult.No)
            {
                Application.Exit();
            }
            else if (result == DialogResult.Cancel)
            {
                MessageBox.Show("Cancel");
            }
        }

        private void btnNewGame_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            this.Refresh();
            this.Hide();
            Form1 NewGame = new Form1();
            NewGame.Show();
        }
    }
}
